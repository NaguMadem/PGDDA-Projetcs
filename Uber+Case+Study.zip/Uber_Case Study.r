#The dataset contains the uber cab booking details from city to airport and airport to city.  
#The Dataset contains the bookings status of the trips such as "Trip completed","was cancelled","
#"No cabs available".

#install.packages("lubridate")
#install.packages("dplyr")
#install.packages("ggplot2")
#install.packages("tidyr")

library(lubridate)
library(dplyr)
library(ggplot2)
library(tidyr)

setwd("F:\\Data Scientist\\R\\Uber Case Study")

uberdata<-read.csv("Uber Request Data.csv", stringsAsFactors = FALSE)
str(uberdata)

#Converting the Request timestamp to standard format
uberdata$Request.timestamp <- parse_date_time(uberdata$Request.timestamp, c("dmy_HMS", "dmy_HM"))
uberdata$Request.timestamp

uberdata$Drop.timestamp <- parse_date_time(uberdata$Drop.timestamp, c("dmy_HMS", "dmy_HM"))
uberdata$Drop.timestamp

sum(is.na(uberdata$Drop.timestamp)) #3914

sum(is.na(uberdata$Driver.id)) #2650.

#divinding the Request time stamp into Weekday,date and hour
uberdata$day<- weekdays.POSIXt(uberdata$Request.timestamp)
uberdata$date<-format(uberdata$Request.timestamp, "%d-%m-%Y")
uberdata$hour<-format(uberdata$Request.timestamp,'%H')

View(uberdata)


#Finding the unique values in uberdata
nrow(uberdata)
apply(uberdata,2,function(x)length(unique(x)))


# Finding the Peak time ( More number of cab bookings time) - Plot:1
ggplot(uberdata, aes(x = uberdata$hour, fill = uberdata$Pickup.point)) + geom_bar(position="dodge") + 
  ggtitle("Availibility of the cars in day time") +
  labs(y="cars",x="Hours") 

# Divinding the hours into names
# Pre_Morning: 4AM to 6AM
# Morning-peakHours: 6AM to 10AM
# Day-time : 10AM - 4PM
# Evening-PeakHours: 4PM to 10PM
# Late Night: 10PM to 4AM

uberdata <- mutate(uberdata,uberdaydata = if_else(hour>=4 & hour <=6, "Pre-Morning",
                                          if_else(hour>=6 & hour<=10, "Morning-PeakHours", 
                                          if_else(hour>=10 & hour <=16, "Day Time", 
                                          if_else(hour>=16 & hour <=22, "Evening-Peakhours","Late Night")))))




uberdata$uberdaydata = as.factor(uberdata$uberdaydata)
summary(uberdata$uberdaydata) # Day Time:1224 Evening_peakHours:2646, Night Time:2875

#Finding the Overall Bookings of the day such as "Trip Completed","was cancelled","No cars available"
#also to find at what cars are not available
#Plot : 2
ggplot(uberdata, aes(x = uberdaydata)) + geom_bar(aes(fill = Status), 
                stat = "count",position = position_dodge()) + 
                ggtitle("Bookings of the day") +labs(y="Demands",x="")


#Finding the Status of the cars booking from City to Airport
#Plot :3
ggplot(uberdata[uberdata$Pickup.point== "City", ]
       , aes(x = uberdaydata)) + 
  geom_bar(aes(fill = Status), stat = "count",
           position = position_dodge()) + 
  ggtitle("City to Airport") +
  labs(y="Demands",x="")


#Find the status of the cabs booking from Airport to City
#Plot:4
ggplot(uberdata[uberdata$Pickup.point== "Airport", ]
       , aes(x = uberdaydata)) + 
  geom_bar(aes(fill = Status), stat = "count",
           position = position_dodge()) + 
  ggtitle("Airport to City") +
  labs(y="Demands",x="")


# Filter the "No cars availble" 
#Plot:5
No_caravailbility <- uberdata[uberdata$Status == "No Cars Available", ]
View(No_caravailbility)

summary(as.factor(No_caravailbility$hour))

ggplot(No_caravailbility, aes(x = hour)) + geom_bar(colour = "red") + 
  ggtitle("No Cars Availability") +
  labs(y="No cars availability",x="day time")



#Filter the "Cancelled cars"
#Plot:6
Cancelledcars<-uberdata[uberdata$Status=="Cancelled",]

#Drawing the graph of cancelled cars at what time
ggplot(Cancelledcars, aes(x = hour)) + geom_bar(colour = "red") + 
  ggtitle("Canceeled Cars") +
  labs(y="Cancelled cars",x="day time")


#graph for Number trips to be done by the driver in timeslots
#plot : 8
ggplot(uberdata,aes(uberdaydata,fill=Pickup.point)) + geom_bar() +
  geom_text(stat="count",aes(label=..count..),position = position_stack(vjust = 0.8)) +
  theme(legend.position = 1,axis.text = element_text(angle = 30, hjust = 1)) +
  labs(title="Count of trip based on day timeslots") + ylab("Number of trips")



#Finding the trip duration
# Drop time - request time
Time_difference <- difftime(uberdata$Drop.timestamp ,uberdata$Request.timestamp,units = c("mins"))
Time_difference

uberdata$tripduration<-round(Time_difference,digits = 1)

  #plot 9: graph for Finding the Median values of Time Duration
  ggplot(uberdata,aes(x = Pickup.point,y = tripduration)) + 
    geom_boxplot(na.rm = T) +   labs(title="Median of Time Duration") + ylab("Trip Duration Time")
    scale_y_continuous(expand = c(0,0))
    
  
  