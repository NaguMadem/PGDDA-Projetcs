#GRAMENER CASE STUDY - Course 2, Group Project 1
# Group Members - 
#   Sateesh Challa
#   Naveen Kumar H V
#   Nagappa Madem
#   Rishabh Mishra


#Importing the libraries needed for data analysis
library(ggplot2)
library(forcats)
library(stringr)
library(dplyr)

#Read the data into Data Frame
loan_data <- read.csv("loan.csv")

### Data Cleansing ### 
## Remove columns with all NA values
loan_data <- loan_data[,colSums(is.na(loan_data))<nrow(loan_data)]

## Remove columns with only one value
loan_data <- Filter(function(x)(length(unique(x))>1), loan_data)

#Rounding off the Column values 
loan_data$funded_amnt_inv <- round(loan_data$funded_amnt_inv)        #Rounding off funded_amnt_inv
loan_data$annual_inc <- round(loan_data$annual_inc)                  #Rounding off annual_inc
loan_data$total_pymnt <- round(loan_data$total_pymnt)                #Rounding off total_pymnt
loan_data$total_pymnt_inv <- round(loan_data$total_pymnt_inv)        #Rounding off total_pymnt_inv
loan_data$collection_recovery_fee <- round(loan_data$collection_recovery_fee,2)        #Rounding off collection_recovery_fee to 2 decimal points


#Removing the 'months' suffix from the term column
term <- strsplit(as.character(loan_data$term),"months")
loan_data$term <- as.integer(term)

#Removing the 'xx' suffix values from Zip code column  
zip <- strsplit(as.character(loan_data$zip_code),"xx")
loan_data$zip_code <- as.integer(zip)

## formatting emp_length column 
#replace 'n/a' with NA
loan_data$emp_length <- str_replace_all(loan_data$emp_length,'n/a','NA')

# replace the values with '< 1' to 0.5
loan_data$emp_length <- str_replace_all(loan_data$emp_length,'< 1 year','0.5')

#remove suffix 'year/years', 'remove + years' in the employee Length column
loan_data$emp_length <- str_replace_all(loan_data$emp_length,'[year,years,+ years]','')

# Replace Blanks with NA for the below columns
# last_pymnt_d, last_credit_pull_d, next_pymnt_d
loan_data$last_pymnt_d[loan_data$last_pymnt_d == ''] <- NA
loan_data$last_credit_pull_d[loan_data$last_credit_pull_d == ''] <- NA
loan_data$next_pymnt_d[loan_data$next_pymnt_d == ''] <- NA

# remove the below columns as they have only zeros or NA
# collections_12_mths_ex_med, chargeoff_within_12_mths, tax_liens
loan_data <- subset(loan_data, select = -c(collections_12_mths_ex_med,chargeoff_within_12_mths,tax_liens))

write.csv(loan_data, "updated_loan_daata.csv")


### Univariate Analysis and Segmented Univariate Analysis
# Effect of different columns on the loan_status which takes below values
# "Fully Paid"  :  Loan is fully paid 
# "Charged Off" :  Defaulted, Loan is not paid 
# "Current"     :  Loan is on going 

loan_data_charged_off <- subset(loan_data, loan_status == "Charged Off")

## Effect of loan_amnt on loan_status
ggplot() + geom_jitter(data = loan_data, aes(x = loan_status, y = loan_amnt, color = loan_status))
# There is no impact of loan amount on loan status, irresprective of the loan amount the probability of the default is same

## Effect of term on loan_status
ggplot() + geom_jitter(data = loan_data, aes(x = loan_status, y = term, color = loan_status))
# There is no impact of term on loan status, irresprective of the term the probability of the default is same

## Effect of installment on loan_status
ggplot() + geom_jitter(data = loan_data_charged_off, aes(x = loan_status, y = installment, color = loan_status))
ggplot() + geom_jitter(data = loan_data, aes(x = loan_status, y = installment, color = loan_status))
# Default cases(Charged Off) are high when the installment is low

## Effect of grade sub grade on loan_status
ggplot(data = loan_data_charged_off, aes(x = grade)) + geom_bar(aes(fill = grade))
# grades B and C are mostly charged off

## Effect of sub grade sub grade on loan_status (default)
ggplot(data = loan_data_charged_off, aes(x = grade, colour = sub_grade, lebel = sub_grade)) + geom_bar()
# B5, B4 , B3, C1 and C2 sub grades contribute more to the laon default (Charged Off)

## Effect of emp_length on loan_status
ggplot(data = loan_data, aes(x = emp_length, fill = loan_status)) + geom_bar(aes(fill = loan_status))
# Theere is no impact of emp_length on the loan status

## Effect of home_ownership on loan_status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = home_ownership)) + geom_bar(fill = "green")
# members that don not own a house are most likley to be charged off

## Effect of annual_inc on loan_status as default ("Charged Off") 
ggplot() + geom_jitter(data = loan_data, aes(x = loan_status, y = annual_inc, color = loan_status))
ggplot(data = loan_data, aes(y = annual_inc, x = id, colour = loan_status)) + geom_line() + scale_x_continuous(breaks = scales::pretty_breaks(n = 11)) + scale_y_continuous(breaks = scales::pretty_breaks(n = 7))
ggplot(data = loan_data, aes(y = annual_inc, x = id, colour = loan_status)) + geom_point()
# there is no impact of annual income in the loan status

## Effect of verification_status on loan_status as default ("Charged Off")   
ggplot(data = loan_data_charged_off, aes(x = verification_status)) + geom_bar(aes(fill = loan_status))
# There is only a marginal impact as "Not Verfied" members are more likely to be defaulted

## Effect of issue_d on loan_status as default ("Charged Off")   
ggplot(data = loan_data, aes(x = fct_infreq(issue_d))) + geom_bar(aes(fill = loan_status))
# Number of loans given is increasing by the issues date,
#from the first date till the date there is a contious growth in the loans issued
# and there is no effect on date on laon being charged off

## Effect of purpose on loan_status as default ("Charged Off")
ggplot(data = loan_data, aes(x = purpose)) + geom_bar(aes(fill = loan_status)) + scale_x_discrete(label = abbreviate)
# When the pupose is "debt_consolidation" the charged off rate is high

## Effect of zip_code on loan_status as default ("Charged Off")    
ggplot(data = loan_data, aes(x = zip_code)) + geom_bar(aes(fill = loan_status))
# There is no impact of zip_code on the loan status

## Effect of addr_state on loan_status as default ("Charged Off")        
ggplot(data = loan_data, aes(x = fct_infreq(addr_state))) + geom_bar(aes(fill = loan_status))
ggplot(data = loan_data_charged_off, aes(x = fct_infreq(addr_state))) + geom_bar(aes(fill = loan_status))
# There is a mriginal increase in the charged off rate for the state CA

## Effect of delinq_2yrs on loan_status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = delinq_2yrs)) + geom_bar(fill = "red")
ggplot(data = loan_data, aes(x = delinq_2yrs)) + geom_bar(aes(fill = loan_status))
# There is no impact of delinq_2yrs on the loan status

## Effect of inq_last_6mths on loan_status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = inq_last_6mths)) + geom_bar(fill = "red")
ggplot(data = loan_data, aes(x = inq_last_6mths)) + geom_bar(aes(fill = loan_status))
# There is no impact of inq_last_6mths on the loan status

## Effect of mths_since_last_delinq on loan_status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = mths_since_last_delinq)) + geom_bar(fill = "red")
ggplot(data = loan_data, aes(x = mths_since_last_delinq)) + geom_bar(aes(fill = loan_status))
# There is no impact of mths_since_last_delinq on the loan status

## Effect of mths_since_last_record on loan_status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = mths_since_last_record)) + geom_bar(fill = "red")
ggplot(data = loan_data, aes(x = mths_since_last_record)) + geom_bar(aes(fill = loan_status))
# There is no impact of mths_since_last_record on the loan status

## Effect of open_acc on loan_status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = open_acc)) + geom_bar(fill = "red")
ggplot(data = loan_data, aes(x = open_acc)) + geom_bar(aes(fill = loan_status))
# There is a marginal impact of open_acc when the values are between 6 to 13

## Effect of pub_rec on loan status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = pub_rec)) + geom_bar(fill = "red")
ggplot(data = loan_data, aes(x = pub_rec)) + geom_bar(aes(fill = loan_status))
# There is no impact of pub_rec on the loan status

## Effect of revol_bal on loan_status as default ("Charged Off") 
  ggplot(data = loan_data_charged_off, aes(x = revol_bal)) + geom_bar(fill = "red")
  ggplot(data = loan_data, aes(x = revol_bal)) + geom_bar(aes(fill = loan_status))
# There is no impact of revol_bal on the loan status

## Effect of  total_acc on loan_status as default ("Charged Off") 
ggplot(data = loan_data_charged_off, aes(x = total_acc)) + geom_bar(fill = "red")
ggplot(data = loan_data, aes(x = total_acc)) + geom_bar(aes(fill = loan_status))
# There is no impace of total_acc on the loan status

## Effect of out_prncp on loan_staus as default ("Charged Off") 
  ggplot(data = loan_data_charged_off, aes(x = out_prncp)) + geom_bar()
  ggplot(data = loan_data, aes(x = out_prncp)) + geom_bar(aes(fill = loan_status))
# Most of the values ate zero in this field, There is no impact of out_prncp on the loan status

## Effect of out_prncp_inv on loan_status as default ("Charged Off") 
  ggplot(data = loan_data_charged_off, aes(x = out_prncp_inv)) + geom_bar()
  ggplot(data = loan_data, aes(x = out_prncp_inv)) + geom_bar(aes(fill = loan_status))
# There is no impact of out_prncp_inv on the loan status

## Effect of open_acc on loan_status as default ("Charged Off") 
ggplot(data = loan_data, aes(x = total_pymnt)) + geom_bar(aes(fill = loan_status))

## Effect of total_rec_prncp on loan_status as default ("Charged Off")     
ggplot(data = loan_data, aes(x = sum(total_rec_prncp), y = loan_status)) + geom_line()
ggplot(data = loan_data, aes(x = total_rec_prncp)) + geom_bar(aes(fill = loan_status))

## Effect of total_rec_prncp on loan_status as default ("Charged Off")  
ggplot(data = loan_data, aes(x = total_rec_prncp, fill = loan_status)) + geom_histogram(bins = 30)
#When the total_rec_prncp (Principal received to date) is low chances of charged off is high

## Effect of total_rec_int on loan_status as default ("Charged Off")  
ggplot(data = loan_data, aes(x = total_rec_int, fill = loan_status)) + geom_histogram(bins = 30)
ggplot(data = loan_data, aes(x = total_rec_int)) + geom_bar(aes(fill = loan_status))
#When the total_rec_int (Interest received to date) is low chances of charged off is high

## Effect of total_rec_late_fee on loan_status as default ("Charged Off")  
ggplot(data = loan_data, aes(x = total_rec_late_fee, fill = loan_status)) + geom_histogram(bins = 30)
#There is no impact of total_rec_late_fee (Late fees received to date) on loan status

## Effect of recoveries on total_pymnt as default ("Charged Off")  
ggplot(data = loan_data, aes(x = recoveries, fill = loan_status)) + geom_histogram(bins = 30)
#There is no impact of recoveries (post charge off gross recovery) on loan status

## Effect of collection_recovery_fee on loan_status as default ("Charged Off")  
ggplot(data = loan_data, aes(x = collection_recovery_fee, fill = loan_status)) + geom_histogram(bins = 30)
#There is no impact of recoveries (post charge off gross recovery) on loan status

## Effect of issue_d on last_pymnt_d as default ("Charged Off")   
ggplot(data = loan_data, aes(x = fct_infreq(last_pymnt_d))) + geom_bar(aes(fill = loan_status))
# There is no impact of last_pymnt_d on the loan sttaus as Charged Off

## Effect of last_pymnt_amnt on loan_status as default ("Charged Off")  
ggplot(data = loan_data, aes(x = last_pymnt_amnt, fill = loan_status)) + geom_histogram()
ggplot(data = loan_data, aes(x = last_pymnt_amnt)) + geom_bar(aes(fill = loan_status))
#There is no impact of last_pymnt_amnt on loan status

## Effect of issue_d on last_credit_pull_d as default ("Charged Off")   
ggplot(data = loan_data, aes(x = fct_infreq(last_credit_pull_d))) + geom_bar(aes(fill = loan_status))
# There is no impact of last_credit_pull_d on the loan sttaus as Charged Off

### Bivariate Analysis

##Recoveries vs collection_recovery_fee
plot(loan_data$recoveries, loan_data$collection_recovery_fee, xlab = "recoveries", ylab = "collection recoveries")
abline(lm(loan_data$collection_recovery_fee ~ loan_data$recoveries))
##There is lot of recoveries happening which indicates that there is default in the loan payment 
##and the payment is being collected manually.

##dti vs loan_status - Higher the dti ratio the chances of customers will be defaulted.
ggplot(data = loan_data, aes(x = dti, fill = loan_status)) + geom_histogram(bins = 30)
## There is an impact on the DTI ratio of the customer and high ratio results in loan status as charged off

##dti vs home_ownership - Higher chance of Mortgage type defaulting the loan having ration between 10-20%
ggplot(data = loan_data, aes(x = dti, fill = home_ownership)) + geom_histogram(bins = 30)
## There is an impact on DTI ration against the home ownership resulting in default

##dti vs installment 
plot(loan_data$installment, loan_data$dti, xlab = "installment", ylab = "dti")
## Customers with DTI ratio between 10-25 has the higher chance of loan status to default 
## and there is an impact on the loan_status to default 

##dti vs purpose - Higher chance of customers with debt_consolidation defaulting the loan
##having DTI ratio between 0-25%
ggplot(data = loan_data, aes(x = dti, fill = purpose)) + geom_histogram(bins = 30)
##customers availed loan for debt consolidation & Credit card usage and having dti ratio between 10-20 
##seems to have high chance of their loan to be charged off.

## annual_inc vs Employee Length - Risk of lending loan to High experienced with Low income
ggplot(data = loan_data, aes(x = annual_inc, y = emp_length)) + geom_line()
## There is a direct impact on the loan status if the employee is highly experienced and 
##having low income. Also, Low experience customers are risky borrowers
