# Case Study - Time Series - Retail-Giant Sales Forecasting #

#Loading libraries
library("ggplot2")
library("graphics")
library("forecast")
library("lubridate")
library("dplyr")
library("tseries")

#Loading Data
Global_Superstore_Master <- read.csv("Global Superstore.csv", stringsAsFactors = F)

#Checking missing value in complete dataset
sum(is.na(Global_Superstore_Master))  #41926

#Selecting only the required fields for analysis
Global_Superstore <- Global_Superstore_Master[c("Order.Date","Segment","Market","Sales","Quantity","Profit")]

#Checking missing value
sum(is.na(Global_Superstore)) # no missing value in the required set

#Converting Order.Date in data format
Global_Superstore$Order.Date <- dmy(Global_Superstore$Order.Date)

#Replace days by first date of the month
mday(Global_Superstore$Order.Date) <- 01

# Aggregate Sales, Quantiy, and Profit by Segment, Market and Order.Date
Global_Superstore_Agg <- group_by(Global_Superstore, Segment, Market, Order.Date) %>% 
  summarise(Sales_Agg=sum(Sales), Quantity_Agg=sum(Quantity), Profit_Agg=sum(Profit))

# Compute Cofficient of Variable(CV) for aggregated Profit and short the data in assending order of CV
Global_Superstore_profit <- group_by(Global_Superstore_Agg,Segment, Market) %>% 
  summarise(CV=sd(Profit_Agg)/mean(Profit_Agg)) %>% arrange(CV)

#To visualize coeff. of variance of Monthly Profit for different Market segments
ggplot(Global_Superstore_profit,aes(x=factor(Market),y=CV,fill=factor(Segment))) + 
  geom_bar(stat="identity",position="dodge")+xlab("Market") + 
  ylab("Coeff. of variance of Monthly Profit") + 
  ggtitle("Coeff. of variance in Monthly Profit Vs. Market Segment") + 
  theme(plot.title = element_text(hjust = 0.5)) + 
  geom_text(aes(label=round(CV,2)), vjust=1.5, color='black', position=position_dodge(.9), size=4)

#Based on the coefficient variance of Monthly Profit we have chosen below two Market Segements
#1. EU Consumer
#2. APAC Consumer

#Subseting the dataset for Segment== "Consumer", Market == "EU"
eu_consumer <- filter(Global_Superstore_Agg, Segment=="Consumer", Market=="EU") %>% arrange(Order.Date)

#Subseting the dataset for Segment=="Consumer", Market=="APAC"
apac_consumer <- filter(Global_Superstore_Agg, Segment=="Consumer", Market=="APAC") %>% arrange(Order.Date)

#To see no. of rows for EU and APAC Market segments
nrow(eu_consumer)     #48
nrow(apac_consumer)   #48

#To generate month sequence numbers
Month=1:nrow(apac_consumer)

#To catagorize the training and test data for EU and APAC market segments
eu_consumer <- cbind(eu_consumer,Month=Month)
apac_consumer <- cbind(apac_consumer,Month=Month)

eu_consumer_in <- eu_consumer[1:42,]
eu_consumer_out <- eu_consumer[43:48,]

apac_consumer_in <- apac_consumer[1:42,]
apac_consumer_out <- apac_consumer[43:48,]

#################### EU Consumer ####################                               
###### TIME SERIES Analysis for EU Consumer Sales(ARMA) ######
Total_EU_Consumer_Sales_TS <- ts(eu_consumer$Sales_Agg)
plot(Total_EU_Consumer_Sales_TS)

EU_Consumer_Sales_in_TS <- ts(eu_consumer_in$Sales_Agg)
plot(EU_Consumer_Sales_in_TS)

#Smoothing the series - Moving Average Smoothing
w <- 1
smoothedseries <- stats::filter(EU_Consumer_Sales_in_TS,filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)
smoothedseries

# Smoothing left end of the time series #
diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

# Smoothing right end of the time series #
n <- length(EU_Consumer_Sales_in_TS)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series
timevals_in <- eu_consumer_in$Month
lines(smoothedseries, col="blue", lwd=2)

# Amplitude of the seasonal curve does not seem increasing with time
smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')

#Now, let's fit a additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit1 <- lm(Sales ~ sin(0.5*Month) + cos(0.5*Month) + Month, data=smootheddf)
summary(lmfit1) #Adjusted R-squared:  0.7053
global_pred1 <- predict(lmfit1, Month=timevals_in)
summary(global_pred1)

plot(EU_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred1, col='red', lwd=2)

lmfit2 <- lm(Sales ~ sin(0.5*Month) * poly(Month,2) + cos(0.5*Month) * poly(Month,2) + Month, data=smootheddf)
summary(lmfit2) # Adjusted R-squared:  0.7456
global_pred2 <- predict(lmfit2, Month=timevals_in)
summary(global_pred2)

plot(EU_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred2, col='red', lwd=2)

lmfit3 <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3) + Month, data=smootheddf)
summary(lmfit3) # Adjusted R-squared:  0.835
global_pred3 <- predict(lmfit3, Month=timevals_in)
summary(global_pred3)

plot(EU_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred3, col='red', lwd=2)

lmfit4 <- lm(Sales ~ sin(0.5*Month) * poly(Month,4) + cos(0.5*Month) * poly(Month,4) + Month, data=smootheddf)
summary(lmfit4) # Adjusted R-squared:  0.8209
global_pred4 <- predict(lmfit4, Month=timevals_in)
summary(global_pred4)

plot(EU_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred4, col='red', lwd=2)

# lmfit3 does fit well and we will consider for the global component as the adjusted R-squared is 0.835 for the poly degree 3
#Now, let's look at the locally predictable series, We will model it as an ARMA series
local_pred <- EU_Consumer_Sales_in_TS - global_pred3
local_pred
plot(local_pred, col='red', type = "l")

acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise
resi <- local_pred - fitted(armafit)
adf.test(resi,alternative = "stationary") # p-value = 0.01(<0.05)
kpss.test(resi) # p-value = 0.1 (>0.05)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
outdata <- eu_consumer_out
timevals_out <- outdata$Month

global_pred_out <- predict(lmfit3,data.frame(Month=timevals_out))
fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
MAPE_class_dec <- accuracy(fcast, outdata$Sales_Agg)[5]
MAPE_class_dec
# 92.95788

#Let's also plot the predictions along with original values & plot the graph
class_dec_pred <- c(ts(global_pred3),ts(global_pred_out))
plot(EU_Consumer_Sales_in_TS, col = "black")
lines(class_dec_pred, col = "red")

########################## TIME SERIES Analysis for EU Consumer Sales(AUTO ARIMA) ################################
# Segment:Consumer 
# Market: EU SALES
autoarima <- eu_consumer_in$Sales_Agg %>% auto.arima()
autoarima

tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise
timeser <- ts(eu_consumer_in$Sales_Agg)
resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary") 
kpss.test(resi_auto_arima) 
# we are getting p-value = 0.1 > 0.05

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,eu_consumer_out$Sales_Agg)[5]
MAPE_auto_arima 
#28.9226

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit
auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(eu_consumer$Sales_Agg, col = "black")
lines(auto_arima_pred, col = "red")

# MAPE value for ARMA(manual) is 92.95788 where as for auto ARIMA is 28.9226.
# so auto ARIMA here is better for forcasting.

# lets model the same model using all data and try forcasting for next 6 months.
eu_consumer$Sales_Agg %>% auto.arima() %>% predict( n.ahead = 6)

########################## TIME SERIES Analysis for EU Consumer Quantity(ARMA) ################################
# TIME SERIES Analysis for Sales
Total_EU_Consumer_Qty_TS <- ts(eu_consumer$Quantity_Agg)
plot(Total_EU_Consumer_Qty_TS)

EU_Consumer_Qty_in_TS <- ts(eu_consumer_in$Quantity_Agg)
plot(EU_Consumer_Qty_in_TS)

#Smoothing the series - Moving Average Smoothing
w <- 1
smoothedseries <- stats::filter(EU_Consumer_Qty_in_TS, filter=rep(1/(2*w+1),(2*w+1)), method='convolution', sides=2)

#Smoothing left end of the time series
diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series
n <- length(EU_Consumer_Qty_in_TS)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series
timevals_in <- eu_consumer_in$Month
lines(smoothedseries, col="blue", lwd=2)
# Amplitude of the seasonal curve does not seemto increase with time
# so will try fitting additive model for the case
smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')

#Now, let's fit a additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit1 <- lm(Sales ~ sin(0.5*Month) + cos(0.5*Month) + Month, data=smootheddf)
summary(lmfit1) # Adjusted R-squared:  0.8393
global_pred1 <- predict(lmfit1, Month=timevals_in)
summary(global_pred1)

plot(EU_Consumer_Qty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred1, col='red', lwd=2)

lmfit2 <- lm(Sales ~ sin(0.5*Month) * poly(Month,2) + cos(0.5*Month) * poly(Month,2) + Month, data=smootheddf)
summary(lmfit2) # Adjusted R-squared:  0.8666 
global_pred2 <- predict(lmfit2, Month=timevals_in)
summary(global_pred2)

plot(EU_Consumer_Qty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred2, col='red', lwd=2)

lmfit3 <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3) + Month, data=smootheddf)
summary(lmfit3) #Adjusted R-squared:  0.8814 
global_pred3 <- predict(lmfit3, Month=timevals_in)
summary(global_pred3)

plot(EU_Consumer_Qty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred3, col='red', lwd=2)

lmfit4 <- lm(Sales ~ sin(0.5*Month) * poly(Month,4) + cos(0.5*Month) * poly(Month,4) + Month, data=smootheddf)
summary(lmfit4) # Adjusted R-squared:  0.8731 
global_pred4 <- predict(lmfit4, Month=timevals_in)
summary(global_pred4)

plot(EU_Consumer_Qty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred4, col='red', lwd=2)

# Checking the Adjusted R-squared and also considering complexity of models, 
# lmfit3 with poly degree 3 seems most appropriate as it seems to have better Adj. R squared of 0.8814

#Now, let's look at the locally predictable series
#We will model it as an ARMA series
local_pred <- EU_Consumer_Qty_in_TS-global_pred3
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)
tsdiag(armafit)
armafit

#We'll check if the residual series is white noise
resi <- local_pred-fitted(armafit)
adf.test(resi,alternative = "stationary") 
# we have p-value = 0.01 (<0.05)
kpss.test(resi) 

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
outdata <- eu_consumer_out
timevals_out <- outdata$Month

global_pred_out <- predict(lmfit3,data.frame(Month =timevals_out))
local_pred_out <- predict(armafit, n.ahead = 6)
fcast <- global_pred_out + local_pred_out$pred

#Now, let's compare our prediction with the actual values, using MAPE
MAPE_class_dec <- accuracy(fcast,outdata$Quantity_Agg)[5]
MAPE_class_dec
#31.45475

#Let's also plot the predictions along with original values 
class_dec_pred <- c(ts(global_pred2),ts(global_pred_out))
plot(Total_EU_Consumer_Qty_TS, col = "black")
lines(class_dec_pred, col = "red")

########################## TIME SERIES Analysis for EU Consumer  Quantity(Auto ARIMA) ################################
# Segment: Consumer    
# Market : EU SALES
autoarima <- eu_consumer_in$Quantity_Agg %>% auto.arima()
autoarima

tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise
timeser <- ts(eu_consumer_in$Quantity_Agg)
resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,eu_consumer_out$Quantity_Agg)[5]
MAPE_auto_arima
#30.13319

#plot the predictions along with original values
auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(eu_consumer$Quantity_Agg, col = "black")
lines(auto_arima_pred, col = "red")

# MAPE value for ARMA(manual) is 31.45475 where as for auto ARIMA is 30.13319.
# so auto ARIMA here is better for forcasting.
# lets model the same model using all data and try forcasting for next 6 months.
eu_consumer$Quantity_Agg %>% auto.arima() %>% predict( n.ahead = 6)

#$pred
#Time Series:
#  Start = 49 
#End = 54 
#Frequency = 1 
#[1] 626.2009 786.6056 842.9179 704.8258 768.6274 807.6497

#$se
#Time Series:
#  Start = 49 
#End = 54 
#Frequency = 1 
#[1] 158.4267 164.8985 167.4396 200.2292 209.7777 214.9378

########################## TIME SERIES Analysis for APAC Consumer ################################
###### TIME SERIES Analysis for APAC Consumer Sales(ARMA) ######
Total_APAC_Consumer_Sales_TS <- ts(apac_consumer$Sales_Agg)
plot(Total_APAC_Consumer_Sales_TS)

APAC_Consumer_Sales_in_TS <- ts(apac_consumer_in$Sales_Agg)
plot(APAC_Consumer_Sales_in_TS)

#Smoothing the series - Moving Average Smoothing
w <- 1
smoothedseries <- stats::filter(APAC_Consumer_Sales_in_TS,filter=c(0.3,0.6,0.1), method='convolution', sides=2)
smoothedseries

#Smoothing left end of the time series
diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series
n <- length(EU_Consumer_Sales_in_TS)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series
timevals_in <- eu_consumer_in$Month
lines(smoothedseries, col="blue", lwd=2)
# Amplitude of the seasonal curve does not seem increasing with time
# so will try fitting additive model for the case

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')

#Now, let's fit a additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit1 <- lm(Sales ~ sin(0.5*Month) + cos(0.5*Month) + Month, data=smootheddf)
summary(lmfit1) #Adjusted R-squared:  0.6428
global_pred1 <- predict(lmfit1, Month=timevals_in)
summary(global_pred1)

plot(APAC_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred1, col='red', lwd=2)

lmfit2 <- lm(Sales ~ sin(0.5*Month) * poly(Month,2) + cos(0.5*Month) * poly(Month,2) + Month, data=smootheddf)
summary(lmfit2) # Adjusted R-squared:  0.75296
global_pred2 <- predict(lmfit2, Month=timevals_in)
summary(global_pred2)

plot(APAC_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred2, col='red', lwd=2)

lmfit3 <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3) + Month, data=smootheddf)
summary(lmfit3) # Adjusted R-squared:  0.7523
global_pred3 <- predict(lmfit3, Month=timevals_in)
summary(global_pred3)

plot(APAC_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred3, col='red', lwd=2)

lmfit4 <- lm(Sales ~ sin(0.5*Month) * poly(Month,4) + cos(0.5*Month) * poly(Month,4) + Month, data=smootheddf)
summary(lmfit4) # Adjusted R-squared:  0.7372
global_pred4 <- predict(lmfit4, Month=timevals_in)
summary(global_pred4)

plot(APAC_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred4, col='red', lwd=2)

acf(smoothedseries)

lmfit5 <- lm(Sales ~ sin(0.5*Month) + poly(Month,3)+ cos(0.5*Month)# *poly(Month,3)
             +sin(1*Month)  + cos(1*Month)
             + Month, data=smootheddf)
summary(lmfit5) # Adjusted R-squared:  0.7503
global_pred5 <- predict(lmfit5, Month=timevals_in)
summary(global_pred5)

plot(APAC_Consumer_Sales_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(global_pred5, col='red', lwd=2)
# lmfit3 does fit well and we will consider for the global component as the adjusted R-squared is 0.835 for the poly degree 3

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- APAC_Consumer_Sales_in_TS - global_pred5
local_pred
plot(local_pred, col='red', type = "l")

acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise
resi <- local_pred - fitted(armafit)
adf.test(resi,alternative = "stationary") # p-value = 0.01(<0.05)
kpss.test(resi) # p-value = 0.1 (>0.05)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
outdata <- apac_consumer_out
timevals_out <- outdata$Month

global_pred_out <- predict(lmfit5,data.frame(Month =timevals_out))

fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
MAPE_class_dec <- accuracy(fcast, outdata$Sales_Agg)[5]
MAPE_class_dec
# 23.3

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred5),ts(global_pred_out))
plot(Total_APAC_Consumer_Sales_TS, col = "black")
lines(class_dec_pred, col = "red")

########################## TIME SERIES Analysis for APAC Consumer  Sales(Auto ARIMA) ################################
# Segment: Consumer    Market: APAC  SALES
autoarima <- apac_consumer_in$Sales_Agg %>% auto.arima()
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise
timeser <- ts(apac_consumer_in$Quantity_Agg)
resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,apac_consumer_out$Sales_Agg)[5]
MAPE_auto_arima
#27.68952

#plot the predictions along with original values
auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(apac_consumer$Sales_Agg, col = "black", type='l')
lines(auto_arima_pred, col = "red")

# MAPE value for ARMA(manual) is 23.3 where as for auto ARIMA is 27.68952.
# so Classical decomposition here is better for forcasting.
# lets model the same model using all data and try forcasting for next 6 months.
next_6months = c(49:54)
APACSales_Next6months <- predict(lmfit5,data.frame(Month =next_6months))
APACSales_Next6months

#1        2        3        4        5        6 
#61090.12 52724.84 47037.47 48209.54 54964.18 61993.24 
#plotting the predictions for next 6 months

Sales_forecast<- c(ts(class_dec_pred),ts(APACSales_Next6months))
plot(Sales_forecast, col = "red", type='l')
lines(apac_consumer$Sales_Agg, col = "black")

###### TIME SERIES Analysis for APAC Consumer Quantity (ARMA) ######
Total_APAC_Consumer_Qnty_TS <- ts(apac_consumer$Quantity_Agg)
plot(Total_APAC_Consumer_Qnty_TS)

APAC_Consumer_Qnty_in_TS <- ts(apac_consumer_in$Quantity_Agg)
plot(APAC_Consumer_Qnty_in_TS)

#Smoothing the series - Moving Average Smoothing
w <- 1
smoothedseries <- stats::filter(APAC_Consumer_Qnty_in_TS,filter=c(0.3,0.5,0.3), method='convolution', sides=2)
smoothedseries

#Smoothing left end of the time series
diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series
n <- length(EU_Consumer_Sales_in_TS)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series
timevals_in <- apac_consumer_in$Month
lines(smoothedseries, col="blue", lwd=2)

# Amplitude of the seasonal curve does not seem increasing with time
# so will try fitting additive model for the case
smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')

#Now, let's fit a additive model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit1 <- lm(Sales ~ sin(0.5*Month) + cos(0.5*Month) + Month, data=smootheddf)
summary(lmfit1) #Adjusted R-squared:  0.6865
global_pred1 <- predict(lmfit1, Month=timevals_in)
summary(global_pred1)

plot(APAC_Consumer_Qnty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred1, col='red', lwd=2)

lmfit2 <- lm(Sales ~ sin(0.5*Month) * poly(Month,2) + cos(0.5*Month) * poly(Month,2) + Month, data=smootheddf)
summary(lmfit2) # Adjusted R-squared:  0.7945
global_pred2 <- predict(lmfit2, Month=timevals_in)
summary(global_pred2)

plot(APAC_Consumer_Qnty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred2, col='red', lwd=2)

lmfit3 <- lm(Sales ~ sin(0.5*Month) * poly(Month,3) + cos(0.5*Month) * poly(Month,3) + Month, data=smootheddf)
summary(lmfit3) # Adjusted R-squared:  0.8017
global_pred3 <- predict(lmfit3, Month=timevals_in)
summary(global_pred3)

plot(APAC_Consumer_Qnty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred3, col='red', lwd=2)

lmfit4 <- lm(Sales ~ sin(0.5*Month) * poly(Month,4) + cos(0.5*Month) * poly(Month,4) + Month, data=smootheddf)
summary(lmfit4) # Adjusted R-squared:  0.7991
global_pred4 <- predict(lmfit4, Month=timevals_in)
summary(global_pred4)

plot(APAC_Consumer_Qnty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(timevals_in, global_pred4, col='red', lwd=2)

acf(smoothedseries)

lmfit5 <- lm(Sales ~ sin(0.5*Month) + poly(Month,3)+ cos(0.5*Month)# *poly(Month,3)
             +sin(1*Month)  + cos(1*Month)
             + Month, data=smootheddf)
summary(lmfit5) # Adjusted R-squared:  0.7968
global_pred5 <- predict(lmfit5, Month=timevals_in)
summary(global_pred5)

plot(APAC_Consumer_Qnty_in_TS)
lines(smoothedseries, col="blue", lwd=2)
lines(global_pred5, col='red', lwd=2)
# lmfit3 does fit well and we will consider for the global component as the adjusted R-squared is 0.835 for the poly degree 3

#Now, let's look at the locally predictable series
#We will model it as an ARMA series
local_pred <- APAC_Consumer_Qnty_in_TS - global_pred5
local_pred
plot(local_pred, col='red', type = "l")

acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise
resi <- local_pred - fitted(armafit)
adf.test(resi,alternative = "stationary") # p-value = 0.01(<0.05)
kpss.test(resi) # p-value = 0.1 (>0.05)

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
outdata <- apac_consumer_out
timevals_out <- outdata$Month
global_pred_out <- predict(lmfit5,data.frame(Month =timevals_out))
fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
MAPE_class_dec <- accuracy(fcast, outdata$Quantity_Agg)[5]
MAPE_class_dec
# 20.327

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit
class_dec_pred <- c(ts(global_pred5),ts(global_pred_out))
plot(Total_APAC_Consumer_Qnty_TS, col = "black")
lines(class_dec_pred, col = "red")

########################## TIME SERIES Analysis for APAC Consumer  Quantity(Auto ARIMA) ################################
# Segment: Consumer    Market: APAC  SALES
autoarima <- apac_consumer_in$Quantity_Agg %>% auto.arima()
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise
timeser <- ts(apac_consumer_in$Quantity_Agg)
resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,apac_consumer_out$Quantity_Agg)[5]
MAPE_auto_arima
#26.24458

#plot the predictions along with original values
auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(apac_consumer$Quantity_Agg, col = "black", type='l')
lines(auto_arima_pred, col = "red")

# MAPE value for ARMA(manual) is 20.3 where as for auto ARIMA is 26.244
# so Classical decomposition here is better for forcasting.
# lets model the same model using all data and try forcasting for next 6 months.
next_6months = c(49:54)
APACQty_Next6months <- predict(lmfit5,data.frame(Month =next_6months))
APACQty_Next6months

#1        2        3        4        5        6 
#782.6218 683.3805 604.7233 603.7363 676.5101 765.4562  
#plotting the predictions for next 6 months
Quantity_forecast<- c(ts(class_dec_pred),ts(APACQty_Next6months))
plot(Quantity_forecast, col = "red", type='l')
lines(apac_consumer$Quantity_Agg, col = "black")