#--HR Group Case Study--##
# Team Members: Naveen Kumar,Paviya Chemparathy,Nagappa Madem,Himanshu Gupta
#AIM: To Predict the target variable Attrition
#The aim is to automate the process of predicting
#if a employee would leave or not and to find the factors affecting the attrition
##################################################################################  

#Installing all the required packages
library(tidyr)
library(dplyr)
library(stringr)
library(ggplot2)
library(MASS)
library(car)
library(e1071)
library(caret)
library(cowplot)
library(caTools)

#Importing the all the csv files
Emp_Data<-read.csv("employee_survey_data.csv",header = TRUE, stringsAsFactors = FALSE)
Gen_Data<-read.csv("general_data.csv",header = TRUE, stringsAsFactors = FALSE)
Manage_Data<-read.csv("manager_survey_data.csv",header=TRUE,  stringsAsFactors = FALSE)
Intime_Data<-read.csv("in_time.csv")
outtime_Data<-read.csv("out_time.csv")

str(Emp_Data)           #4410 obs of 4 variables 
str(Gen_Data)           #4410 obs of 24 variables 
str(Manage_Data)        #4410 obs of 3 variables 
str(Intime_Data)        #4410 obs of 262 variables 
str(outtime_Data)       #4410 obs of 262 variables 

#Data Preparation
#Checking the NA values 
sum(is.na(Emp_Data))      #83 NA values
summary(Emp_Data)         #count of NA values for each column
sum(is.na(Gen_Data))      #28 NA Values
summary(Gen_Data)         #count of NA Values for each column
sum(is.na(Manage_Data))   #0 NA Values

#Checking duplicate values
which(duplicated(Emp_Data))     #NO duplicate Values
which(duplicated(Gen_Data))     #NO duplicate Values
which(duplicated(Manage_Data))  #NO duplicate Values

#Finding the Unique Values
length(unique(tolower(Emp_Data$EmployeeID)))
length(unique(tolower(Gen_Data$EmployeeID)))
length(unique(tolower(Manage_Data$EmployeeID)))

#Now all the files are Identical. Checking the all files are Identical or not
setdiff(Gen_Data$EmployeeID,Emp_Data$EmployeeID)
setdiff(Gen_Data$EmployeeID,Manage_Data$EmployeeID)

#Processing in_time & out_time
#In & out time data have 1 year working days data of login & logout times, assuming holidays & leave days are NA 
#Removing columns with all NA values assuming that those days were holidays
Remove_Intime<-c(colnames(Intime_Data)[colSums(is.na(Intime_Data))==4410])
Remove_Intime

#outtime
Remove_outtime<-c(colnames(outtime_Data)[colSums(is.na(outtime_Data))==4410])
Remove_outtime

#intime
Intime_Data<-Intime_Data[,-which(names(Intime_Data)%in%Remove_Intime)]
print(Intime_Data)

#outtime
outtime_Data<-outtime_Data[,-which(names(outtime_Data)%in%Remove_outtime)]
print(outtime_Data)

str(Intime_Data)  #dates are in factor form
str(outtime_Data) #dates are in factor form

#introducing the dummy variable
temp<-as.data.frame(apply(Intime_Data[,-1],2,as.POSIXlt))
print(temp)
Intime_Data<-cbind(Intime_Data[,1],temp)
str(Intime_Data)

names(Intime_Data)[names(Intime_Data) == "Intime_Data[, 1]"] <- "EmployeeID" #Renaming first column as 'EmployeeID'
names(Intime_Data) <- str_replace(names(Intime_Data),"X"," ")
View(Intime_Data)

temp<-as.data.frame(apply(outtime_Data[,-1],2,as.POSIXlt))
outtime_Data<-cbind(outtime_Data[,1],temp)
names(outtime_Data)[names(outtime_Data) == "outtime_Data[, 1]"] <- "EmployeeID" #Renaming first column as 'EmployeeID'
names(outtime_Data) <- str_replace(names(outtime_Data),"X"," ")
View(outtime_Data)

#Finding the Leaves
#Finding Leave Patterns
#Deriving total Leaves taken by employee assuming remaining NA are Leaves taken by employee
Leaves<-c(apply(Intime_Data, 1, function(x) sum(is.na(x))))
Leaves

LeavesPerMonth<-vector()
LeavesPerMonth

#Finding the Monthly wise leaves - For 12 months
for(i in 1:12){
  LeavesMonthly<-Intime_Data[,c(which(as.numeric(substr(names(Intime_Data[,-1]),7,8))==i))]
  LeavesPerMonth<-cbind(LeavesPerMonth,apply(LeavesMonthly, 1, function(x) sum(is.na(x))))
}
LeavesPerMonth<-as.data.frame(LeavesPerMonth)
LeavesPerMonth

#Binding the LeavesPerMonth column and General Data Attrition
#As per problem statement need to find General Data Attrition
LeavesPerMonth<-cbind(LeavesPerMonth,Gen_Data$Attrition)
LeavesPerMonth

#Calculating the Average Monthly Leaves, Adding the V1 Values and taking the average using Mean function for Gen_Data Attirtion=
#Yes condition
AverageMonthlyLeavesYes<-c(apply(subset(LeavesPerMonth,LeavesPerMonth$`Gen_Data$Attrition`=="Yes",select = -c(`Gen_Data$Attrition`)),2,mean))
AverageMonthlyLeavesYes

#Calculating the Average Monthly Leaves, Adding the V1 Values and taking the average using Mean function for Gen_Data Attirtion=
#No condition
AverageMonthlyLeavesNo<-c(apply(subset(LeavesPerMonth,LeavesPerMonth$`Gen_Data$Attrition`=="No",select = -c(`Gen_Data$Attrition`)),2,mean))
AverageMonthlyLeavesNo

#binding the row for AverageMonthlyLeaveYes and AverageMonthlyLeaveNo
AverageMonthlyLeaves<-as.data.frame(t(rbind(AverageMonthlyLeavesYes,AverageMonthlyLeavesNo)))
AverageMonthlyLeaves

#Plotting the graph for Average Monthly Leaves Yes and No
#loess - Loess short for Local Regression is a non-parametric approach that fits multiple regressions in local neighborhood.
ggplot() +
  #General Data Attrition=Yes, Red plot
  geom_point(data=AverageMonthlyLeaves, aes(seq_along(AverageMonthlyLeavesYes),AverageMonthlyLeavesYes)) + 
  geom_smooth(method = 'loess',data=AverageMonthlyLeaves, aes(seq_along(AverageMonthlyLeavesYes),AverageMonthlyLeavesYes), colour="red", size=1) +
  #Attrition=No, green plot
  geom_point(data=AverageMonthlyLeaves, aes(seq_along(AverageMonthlyLeavesNo),AverageMonthlyLeavesNo)) +  
  geom_smooth(method = 'loess', data=AverageMonthlyLeaves, aes(seq_along(AverageMonthlyLeavesNo),AverageMonthlyLeavesNo), colour="green", size=1)


#Calculating employees stay time in office
#Outime Data - Intime_Data
work_hours<-outtime_Data[,-1]-Intime_Data[,-1]
work_hours
AverageWorkHours<-vector()
AverageWorkHours

#Finding the Average works hours using mean and looping the 12 observations
for(i in 1:nrow(work_hours))
{
  AverageWorkHours<-c(AverageWorkHours,mean(as.numeric(work_hours[i,]),na.rm=TRUE))
}
AverageWorkHours

#apply(as.numeric(unlist(work_hours)),1,mean,na.rm=TRUE)
work_hours<-cbind(work_hours,AverageWorkHours)
work_hours

#Adding the column EmployeeID and Work hours
work_hours<-cbind(Intime_Data$EmployeeID,work_hours)
names(work_hours)[names(work_hours) == "in_time$EmployeeID"] <- "EmployeeID"
work_hours<-cbind(work_hours,Leaves)
work_hours<-work_hours[,c(1,251,252)]

####################### Intime and OutTime Correcting is done######################
#Merging all the data sets
EDAClean<- merge(Emp_Data,Manage_Data, by="EmployeeID", all = F)
EDAClean<- merge(EDAClean,Gen_Data, by="EmployeeID", all = F)

########################################################################
###Creating Plots with the EDAClean (all Merged Data)
bar_theme1<- theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
                   legend.position="none")

plot_grid(ggplot(EDAClean, aes(x=BusinessTravel,fill=Attrition))+ geom_bar(), 
          ggplot(EDAClean, aes(x=Department,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(EDAClean, aes(x=EducationField,fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h")   


plot_grid(ggplot(EDAClean, aes(x=Gender,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(EDAClean, aes(x=JobRole,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(EDAClean, aes(x=MaritalStatus,fill=Attrition))+ geom_bar() +bar_theme1,
          align = "h") 



plot_grid(ggplot(EDAClean, aes(x=EnvironmentSatisfaction,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(EDAClean, aes(x=JobSatisfaction,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(EDAClean, aes(x=WorkLifeBalance,fill=Attrition))+ geom_bar() +bar_theme1,
          ggplot(EDAClean, aes(x=JobInvolvement,fill=Attrition))+ geom_bar() +bar_theme1,
          ggplot(EDAClean, aes(x=PerformanceRating,fill=Attrition))+ geom_bar() +bar_theme1,
          align = "h")

# Boxplots of numeric variables relative to employee status
box_theme_y<- theme(axis.line.y=element_blank(),axis.title.y=element_blank(), 
                    axis.ticks.y=element_blank(), axis.text.y=element_blank(),
                    legend.position="none")

plot_grid(ggplot(EDAClean, aes(x=Attrition,y=DistanceFromHome, fill=Attrition))+ geom_boxplot(width=0.2)+ 
            coord_flip() +theme(legend.position="none"),
          ggplot(EDAClean, aes(x=Attrition,y=MonthlyIncome, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(EDAClean, aes(x=Attrition,y=TotalWorkingYears, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)

# Missing value 
sapply(EDAClean, function(x) sum(is.na(x)))

# There are 111 NA values
anyNA(EDAClean$Age)                            #No Missing values
anyNA(EDAClean$Attrition)                      #No Missing values
anyNA(EDAClean$BusinessTravel)                 #No Missing values
anyNA(EDAClean$Department)                     #No Missing values  
anyNA(EDAClean$DistanceFromHome)               #No Missing values
anyNA(EDAClean$Education)                      #No Missing values
anyNA(EDAClean$EducationField)                 #No Missing values  
anyNA(EDAClean$EmployeeCount)                  #No Missing values
anyNA(EDAClean$EmployeeNumber)                 #No Missing values
anyNA(EDAClean$EnvironmentSatisfaction)        #HAVE Missing values
anyNA(EDAClean$Gender)                         #No Missing values
anyNA(EDAClean$JobInvolvement)                 #No Missing values
anyNA(EDAClean$JobLevel)                       #No Missing values
anyNA(EDAClean$JobRole)                        #No Missing values
anyNA(EDAClean$JobSatisfaction)                #HAVE Missing Values
anyNA(EDAClean$MaritalStatus)                  #No Missing values
anyNA(EDAClean$MonthlyIncome)                  #No Missing values
anyNA(EDAClean$NumCompaniesWorked)             #HAVE Missing values
anyNA(EDAClean$Over18)                         #No Missing values
anyNA(EDAClean$PercentSalaryHike)              #No Missing values
anyNA(EDAClean$PerformanceRating)              #No Missing values
anyNA(EDAClean$RelationshipSatisfaction)       #No Missing values
anyNA(EDAClean$StandardHours)                  #No Missing values
anyNA(EDAClean$StockOptionLevel)               #No Missing values
anyNA(EDAClean$TotalWorkingYears)              #HAVE Missing values
anyNA(EDAClean$TrainingTimesLastYear)          #No Missing values
anyNA(EDAClean$WorkLifeBalance)                #HAVE Missing values  
anyNA(EDAClean$YearsAtCompany)                 #No Missing values
anyNA(EDAClean$YearsSinceLastPromotion)        #No Missing values
anyNA(EDAClean$YearsWithCurrManager)           #No Missing values 

#cleaning NA for all variables of above by replacing with median or mean
#should we use mode function instead of median and mean

EDAClean$JobSatisfaction[which(is.na(EDAClean$JobSatisfaction))]<- median(EDAClean$JobSatisfaction,na.rm = TRUE)
EDAClean$WorkLifeBalance[which(is.na(EDAClean$WorkLifeBalance))]<- median(EDAClean$WorkLifeBalance,na.rm = TRUE)
EDAClean$NumCompaniesWorked[which(is.na(EDAClean$NumCompaniesWorked))]<- mean(EDAClean$NumCompaniesWorked,na.rm = TRUE)
EDAClean$EnvironmentSatisfaction[which(is.na(EDAClean$EnvironmentSatisfaction))]<- median(EDAClean$EnvironmentSatisfaction,na.rm = TRUE)

#Setting missing TotalWorkingYears values with approx YearsAtCompany value
EDAClean$TotalWorkingYears[which(is.na(EDAClean$TotalWorkingYears))]<- EDAClean$YearsAtCompany[which(is.na(EDAClean$TotalWorkingYears))]

#No values are NA in EDAClean
sapply(EDAClean, function(x) sum(is.na(x)))

# check duplicated
which(duplicated(EDAClean))
# no duplicatee values

####Checking for OUTLIERS####
str(EDAClean)
# Only considered numeric variables for outlier detection
View(sapply(EDAClean[,c(3:6,7,11,12,19,20,23,24,25,27:29)],function(x) quantile(x,seq(0,1,.01),na.rm = T)))

summary(EDAClean)
######################################################################
#Add Total Leaves taken by each employee to the edaclean
EDAClean <- cbind(EDAClean, Leaves)
#Add avg work hours to the edaclean
EDAClean <- cbind(EDAClean, AverageWorkHours)
################################################################

#TotalWorkingYears has got some outliers after 99 percentile, Lets replace with 99% value
boxplot(EDAClean$TotalWorkingYears,main="TotalWorkingYears With outliers")
hist(EDAClean$TotalWorkingYears, main="TotalWorkingYears With outliers")
boxplot.stats(EDAClean$TotalWorkingYears)$stats
quantile(EDAClean$TotalWorkingYears,seq(0,1,0.01))
EDAClean$TotalWorkingYears[which(EDAClean$TotalWorkingYears > 32)] <- 32

#YearsAtCompany has got some outliers after 98 percentile, Lets replace with 98% value
boxplot(EDAClean$YearsAtCompany,main="YearsAtCompany With outliers")
hist(EDAClean$YearsAtCompany, main="YearsAtCompany With outliers")
boxplot.stats(EDAClean$YearsAtCompany)$stats
quantile(EDAClean$YearsAtCompany,seq(0,1,0.01))
EDAClean$YearsAtCompany[which(EDAClean$YearsAtCompany > 24)] <- 24

#YearsWithCurrManager has got some outliers after 99 percentile, Lets replace with 99% value
boxplot(EDAClean$YearsWithCurrManager,main="YearsWithCurrManager With outliers")
hist(EDAClean$YearsAtCompany, main="YearsWithCurrManager With outliers")
boxplot.stats(EDAClean$YearsWithCurrManager)$stats
quantile(EDAClean$YearsWithCurrManager,seq(0,1,0.01))
EDAClean$YearsWithCurrManager[which(EDAClean$YearsWithCurrManager > 14)] <- 14

#Removing outliers for MonthlyIncome
boxplot(EDAClean$MonthlyIncome,main="MonthlyIncome With outliers")
hist(EDAClean$MonthlyIncome, main="MonthlyIncome With outliers")
quantile(EDAClean$MonthlyIncome,seq(0,1,.01),na.rm = T)

#We can see a jump in value in 1% to 2% 13620.6 to 18590.0
EDAClean$MonthlyIncome[which(EDAClean$MonthlyIncome < 18590.0)]<-18590.0

#We can see a jump in value in 95% to 96% 178560.0 to 186437.6
EDAClean$MonthlyIncome[which(EDAClean$MonthlyIncome > 178560.0)]<-178560.0

#Removing outliers for YearsSinceLastPromotion
quantile(EDAClean$YearsSinceLastPromotion,seq(0,1,.01),na.rm = T)
#We can see a sudden jump in value in 95% to 96% 9 to 11
EDAClean$YearsSinceLastPromotion[which(EDAClean$YearsSinceLastPromotion > 9)]<-9


# Feature standardisation

#Converting attrition to numeric 1,0
EDAClean$Attrition<- ifelse(EDAClean$Attrition=="Yes",1,0)

Attrition <- sum(EDAClean$Attrition)/nrow(EDAClean)
Attrition # 16.12% churn rate. 

# Bringing the variables in the correct format
EDAClean$EnvironmentSatisfaction<- ifelse(EDAClean$EnvironmentSatisfaction==1,"Low",ifelse(EDAClean$EnvironmentSatisfaction==2,"Medium",ifelse(EDAClean$EnvironmentSatisfaction==3,"High",ifelse(EDAClean$EnvironmentSatisfaction==4,"Very High",""))))
EDAClean$JobSatisfaction<- ifelse(EDAClean$JobSatisfaction==1,"Low",ifelse(EDAClean$JobSatisfaction==2,"Medium",ifelse(EDAClean$JobSatisfaction==3,"High",ifelse(EDAClean$JobSatisfaction==4,"Very High",""))))
EDAClean$WorkLifeBalance<- ifelse(EDAClean$WorkLifeBalance==1,"Bad",ifelse(EDAClean$WorkLifeBalance==2,"Good",ifelse(EDAClean$WorkLifeBalance==3,"Better",ifelse(EDAClean$WorkLifeBalance==4,"Best",""))))
EDAClean$JobInvolvement<- ifelse(EDAClean$JobInvolvement==1,"Low",ifelse(EDAClean$JobInvolvement==2,"Medium",ifelse(EDAClean$JobInvolvement==3,"High",ifelse(EDAClean$JobInvolvement==4,"Very High",""))))
EDAClean$PerformanceRating<- ifelse(EDAClean$PerformanceRating==1,"Low",ifelse(EDAClean$PerformanceRating==2,"Good",ifelse(EDAClean$PerformanceRating==3,"High",ifelse(EDAClean$PerformanceRating==4,"Very High",""))))
EDAClean$Education<- ifelse(EDAClean$Education==1,"Below College",ifelse(EDAClean$Education==2,"College",ifelse(EDAClean$Education==3,"Bachelor",ifelse(EDAClean$Education==4,"Master","Doctor"))))
EDAClean$JobLevel<- ifelse(EDAClean$JobLevel==1,"JobLevel1",ifelse(EDAClean$JobLevel==2,"JobLevel2",ifelse(EDAClean$JobLevel==3,"JobLevel3",ifelse(EDAClean$JobLevel==4,"JobLevel4","JobLevel5"))))
EDAClean$StockOptionLevel<- ifelse(EDAClean$StockOptionLevel==0,"StockOptLvl0",ifelse(EDAClean$StockOptionLevel==1,"StockOptLvl1",ifelse(EDAClean$StockOptionLevel==2,"StockOptLvl2","StockOptLvl3")))

###Converting the factors features to dummy variables
# Creating a dataframe of categorical features
employee_chr<- EDAClean[,c(2,3,4,5,6,9,10,12,13,15,16,17,18,24)]

# converting categorical attributes to factor
employee_chr<- data.frame(sapply(employee_chr, function(x) factor(x)))
str(employee_chr)

# Creating dummy variables for factor attributes
dummies<- data.frame(sapply(employee_chr, 
                            function(x) data.frame(model.matrix(~x-1,data =employee_chr))[,-1]))


#Merging with dummy variables
employee_final<- cbind(EDAClean[,-c(2,3,4,5,6,9,10,12,13,15,16,17,18,24)],dummies) 
#Removing Over18 as it has only one value
employee_final <- employee_final[,-8]
#Removing Standard hours as it has only one value
employee_final <- employee_final[,-9]
employee_final <- employee_final[,-c(1,5)] #Employee ID, Employee Count
summary(employee_final)

# Normalising continuous features 
employee_final$DistanceFromHome<- scale(employee_final$DistanceFromHome)
employee_final$MonthlyIncome<- scale(employee_final$MonthlyIncome)
employee_final$Age<- scale(employee_final$Age)
employee_final$PercentSalaryHike<- scale(employee_final$PercentSalaryHike)
employee_final$TotalWorkingYears<- scale(employee_final$TotalWorkingYears)
employee_final$TrainingTimesLastYear<- scale(employee_final$TrainingTimesLastYear)
employee_final$YearsAtCompany<- scale(employee_final$YearsAtCompany)
employee_final$YearsWithCurrManager<- scale(employee_final$YearsWithCurrManager)
employee_final$YearsSinceLastPromotion<- scale(employee_final$YearsSinceLastPromotion)
employee_final$NumCompaniesWorked<- scale(employee_final$NumCompaniesWorked)
employee_final$Leaves<- scale(employee_final$Leaves)
employee_final$AverageWorkHours<- scale(employee_final$AverageWorkHours)

#employee_final with 57 variables
View(employee_final)

########################################################################
# splitting the data between train and test
set.seed(100)

indices = sample.split(employee_final$Attrition, SplitRatio = 0.7)

train = employee_final[indices,]

test = employee_final[!(indices),]

########################################################################
# Logistic Regression: 

#Initial model
model_1 = glm(Attrition ~ ., data = train, family = "binomial")
summary(model_1) #AIC 2143.0 coeff..null Dev 2728...resDev 2029

# Stepwise selection
model_2<- stepAIC(model_1, direction="both")

summary(model_2) #AIC 2114.8
# Removing multicollinearity through VIF check
sort(vif(model_2))

#Excluding YearsAtCompany
model_3<- glm(formula = Attrition ~ Age + DistanceFromHome + MonthlyIncome + 
                NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + 
                AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                Department.xResearch...Development + Department.xSales + 
                Education.xBelow.College + Education.xCollege + EducationField.xOther + 
                JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
              data = train)

summary(model_3) 
#AIC 2115.4
sort(vif(model_3)) 

#Excluding BusinessTravel.xTravel_Rarely
model_4<- glm(formula = Attrition ~ Age + DistanceFromHome + MonthlyIncome + 
                NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + 
                AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                BusinessTravel.xTravel_Frequently + 
                Department.xResearch...Development + Department.xSales + 
                Education.xBelow.College + Education.xCollege + EducationField.xOther + 
                JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
              data = train)


summary(model_4) 
#AIC 2131.5
sort(vif(model_4)) 

#Excluding WorkLifeBalance.xBest
model_5<- glm(formula = Attrition ~ Age + DistanceFromHome + MonthlyIncome + 
                NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + 
                AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                BusinessTravel.xTravel_Frequently + Department.xResearch...Development + Department.xSales + 
                Education.xBelow.College + Education.xCollege + EducationField.xOther + 
                JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
              data = train)

summary(model_5) 
#AIC 2142
sort(vif(model_5)) 

#Excluding Department.xSales 
model_6<- glm(formula = Attrition ~ Age + DistanceFromHome + MonthlyIncome + 
                NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + 
                AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                BusinessTravel.xTravel_Frequently + Department.xResearch...Development + 
                Education.xBelow.College + Education.xCollege + EducationField.xOther + 
                JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
              data = train)

summary(model_6) 
#AIC :2165.6
sort(vif(model_6)) 

#VIF model is all less than 2,so we will look into the P-value
#Excluding Department.xResearch...Development as it has high p-value  
model_7<- glm(formula = Attrition ~ Age + DistanceFromHome + MonthlyIncome + 
                NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + 
                AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                BusinessTravel.xTravel_Frequently + Education.xBelow.College + Education.xCollege + EducationField.xOther + 
                JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
              data = train)

summary(model_7) 
#AIC:2164.7

#Excluding  Education.xBelow.College as p-value lower significance   
model_8<- glm(formula = Attrition ~ Age + DistanceFromHome + MonthlyIncome + 
                NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + 
                AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                BusinessTravel.xTravel_Frequently + Education.xCollege + EducationField.xOther + 
                JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
              data = train)

summary(model_8) 
#AIC:2164.7

#Excluding JobInvolvement.xLow   
model_9<- glm(formula = Attrition ~ Age + DistanceFromHome + MonthlyIncome + 
                NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + 
                AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                BusinessTravel.xTravel_Frequently + Education.xCollege + EducationField.xOther + 
                JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
              data = train)

summary(model_9) 
#AIC:2165

#Excluding DistanceFromHome due to lower significance of p-value   
model_10<- glm(formula = Attrition ~ Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + Education.xCollege + EducationField.xOther + 
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
               data = train)

summary(model_10) 
#AIC:2165.6


#Excluding EducationField.xOther due to lower significance   
model_11<- glm(formula = Attrition ~ Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + Education.xCollege + 
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle + StockOptionLevel.xStockOptLvl1, family = "binomial", 
               data = train)

summary(model_11) 
#AIC:2167.8

#Excluding StockOptionLevel.xStockOptLvl1 due to lower significance    
model_12<- glm(formula = Attrition ~ Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + Education.xCollege + 
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle , family = "binomial", 
               data = train)

summary(model_12) 
#AIC 2169.7

#Excluding Education.xCollege   
model_13<- glm(formula = Attrition ~ Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle , family = "binomial", 
               data = train)
summary(model_13) 
#AIC:2171.7


#Excluding EnvironmentSatisfaction.xVery.High   
model_14<- glm(formula = Attrition ~ Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_14) 
#AIC:2171.7

#Excluding EnvironmentSatisfaction.xVery.High 
model_15<- glm(formula = Attrition ~ Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_15) 
#AIC:2174.4

#Excluding MonthlyIncome
model_16<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_16)
#AIC:2177.1

#Excluding JobLevel.xJobLevel2
model_17<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + WorkLifeBalance.xGood + 
                 BusinessTravel.xTravel_Frequently + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_17)
#AIC 2181

##Excluding WorkLifeBalance.xGood
model_18<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + 
                 BusinessTravel.xTravel_Frequently + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_18)
#AIC2184.6

#### Excluding JobRole.xResearch.Scientist
model_19<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + 
                 BusinessTravel.xTravel_Frequently + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_19)

#### Excluding JobRole.xLaboratory.Technician
model_20<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + 
                 BusinessTravel.xTravel_Frequently + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_20)

#### Excluding JobRole.xResearch.Director
model_21<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + 
                 BusinessTravel.xTravel_Frequently + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_21)

#### Excluding JobRole.xSales.Executive
model_22<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBetter + 
                 BusinessTravel.xTravel_Frequently + 
                 MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_22)

#### Excluding WorkLifeBalance.xBetter
model_23<- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 AverageWorkHours + EnvironmentSatisfaction.xLow + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High +
                 BusinessTravel.xTravel_Frequently + 
                 MaritalStatus.xSingle , family = "binomial", data = train)

summary(model_23)

##############################################3
#final model is model_23 with 12 variables
final_model = model_23

test_pred = predict(final_model, type = "response",newdata = test[,-2])


# Let's see the summary 

summary(test_pred)

test$prob <- test_pred
View(test)
# Let's use the probability cutoff of 50%.

test_pred_attrition <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_attrition <- factor(ifelse(test$Attrition==1,"Yes","No"))


table(test_actual_attrition,test_pred_attrition)


#######################################################################
test_pred_attrition <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))
test_conf <- confusionMatrix(test_pred_attrition, test_actual_attrition, positive = "Yes")
test_conf
#######################################################################

# Let's Choose the cutoff value. 
# Let's find out the optimal probalility cutoff 
perform_fn <- function(cutoff) 
{
  predicted_attrition <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_attrition, factor(test_actual_attrition), positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Creating cutoff values from 0.003575 to 0.812100 for plotting and initiallizing a matrix of 100 X 3.

# Summary of test probability

summary(test_pred)

s = seq(.1,.9,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0.5,0.75,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))

cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.016)]

# Let's choose a cutoff value of 0.164 for final model
test_cutoff_attrition <- factor(ifelse(test_pred >=0.164, "Yes", "No"))
conf_final <- confusionMatrix(test_cutoff_attrition, test_actual_attrition, positive = "Yes")

acc <- conf_final$overall[1]
sens <- conf_final$byClass[1]
spec <- conf_final$byClass[2]

acc
#Accuracy = 0.7339 0r 73%
sens
#sensitivity = 0.7323 or 73%
spec
#specificty = 0.7342 or 73%
View(test)
##################################################################################################
### KS -statistic - Test Data ######

test_cutoff_attrition <- ifelse(test_cutoff_attrition=="Yes",1,0)
test_actual_attrition <- ifelse(test_actual_attrition=="Yes",1,0)

library(ROCR)
#on testing  data
pred_object_test<- prediction(test_cutoff_attrition, test_actual_attrition)
performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)

####################################################################
# Lift & Gain Chart 
# plotting the lift chart
# Loading dplyr package 

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Churn_decile = lift(test_actual_attrition, test_pred, groups = 10)
Churn_decile
