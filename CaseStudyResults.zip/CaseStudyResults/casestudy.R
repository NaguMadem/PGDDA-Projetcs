# set the path where data files exists as working directory
#setwd("F:\Data Scientist\R\Gorup Study")

#installing the below packages
#install.packages("tidyr")
#install.packages("dplyr")
#install.packages("sqldf")
#install.packages("gdata")
#install.packages("stringr")

#library files
library(tidyr)
library(dplyr)
library(stringr)

#-----------------------------------------------------------------------------------------------------
#CHECKPOINT 1 Data Cleaning 1:

#Loading the companies data
companies <- read.delim('companies.txt', stringsAsFactors = FALSE)

# converting the permalink columns to lower case, becuase the same column(company_permalink) in round2
# has names in both in upper and lower case, so that the values can be compared
companies$permalink <- sapply(companies$permalink, FUN = tolower) 

#Loading the rounds2 data
rounds2 <- read.csv('rounds2.csv', stringsAsFactors = FALSE)
# converting to lower case as the same url exist few in upper and few in lower case 
rounds2$company_permalink <- sapply(rounds2$company_permalink, FUN = tolower)

#Merging the companies and round2 data frames
master_frame <- merge(companies, rounds2, by.x = 'permalink', by.y = 'company_permalink')
nrow(master_frame)
#-----------------------------------------------------------------------------------------------------
#CHECKPOINT 2 Funding Type Analysis:

### filter the desired funding types 
### group them by funding types and calucate the avg investment 
### arange them in descending order and fetch the funding type with maximum amount in the provided range 
#mf-master frame
mf_filtered_cp2 <- filter(master_frame,!is.na(raised_amount_usd),funding_round_type == "venture" | funding_round_type=="seed"|funding_round_type=="angel"|funding_round_type=="private_equity")
mf_grouped <- group_by(mf_filtered_cp2,funding_round_type)
mf_summary<-summarise(mf_grouped,mean(raised_amount_usd))

cat("Average funding amount of venture type = ",as.numeric(mf_summary[which(mf_summary$funding_round_type=="venture"),2]))
cat("Average funding amount of angel type = ",as.numeric(mf_summary[which(mf_summary$funding_round_type=="angel"),2]))
cat("Average funding amount of seed type = ",as.numeric(mf_summary[which(mf_summary$funding_round_type=="seed"),2]))
cat("Average funding amount of private equity type = ",as.numeric(mf_summary[which(mf_summary$funding_round_type=="private_equity"),2]))

mf_summary_criteria <- filter(mf_summary,`mean(raised_amount_usd)`>=5000000 & `mean(raised_amount_usd)`<=15000000)
FT <- as.character( mf_summary_criteria[which.max(mf_summary_criteria$`mean(raised_amount_usd)`),1])

cat("Most suitable investment type for Spark Funds is ", FT )

#------------------------------------------------------------------------------------------------------------------------------------------------------------------
#CHECKPOINT 3: COUNTRY ANALYSIS
#English speaking countries :
#applying filter for venture investment type
investment_type_venture<-filter(master_frame,master_frame$funding_round_type == FT)

#removing NAs
investment_type_venture<-na.omit(investment_type_venture)

#calculate the sum of funds raised per country
total_funding_venture<-aggregate(investment_type_venture$raised_amount_usd,by=list(investment_type_venture$country_code),FUN=sum)

#top9 countries with the highest funds.
top9<-arrange(total_funding_venture,desc(total_funding_venture$x))[1:9,] 

#top9 country code will display - the country code which we needs to check with pdf - Countries_where_English_is_an_official_language.pdf

COUNTRY_1 <- "USA"
COUNTRY_2 <- "GBR"
COUNTRY_3 <- "IND"
COUNTRY_1
COUNTRY_2
COUNTRY_3

#------------------------------------------------------------------------------------------------------------------------------------------------------------------                                                              
#CHECKPOINT 4: SECTOR ANALYSIS 1:


# create a data frame out of the mapping.csv and clean the data.
mapping <- read.csv("mapping.csv",header = T)

#Data cleaning in mapping df
mapping <- filter(mapping,mapping$category_list!="")
mapping$category_list <- str_replace_all(tolower(mapping$category_list),"0","na")
mapping$category_list <- str_replace_all(tolower(mapping$category_list),"\\.na","\\.0")

### convert the wide data in mapping.csv to long data 

mapping_intermediate <- gather(mapping,sector,sector_val,Automotive...Sports : Social..Finance..Analytics..Advertising)
mapping_final <- mapping_intermediate[!(mapping_intermediate$sector_val == 0),-3]

####merge mapping_final with the master_frame to extract the sectors 
master_frame_cp4<- master_frame
master_frame_cp4$category_list <- tolower(master_frame_cp4$category_list) 
master_frame_cp4_splitted <- separate(master_frame_cp4,category_list,into=c("category_list"),extra = "warn",sep = '\\|')
names(master_frame_cp4_splitted)
master_frame_withsector <- merge(x=master_frame_cp4_splitted,y=mapping_final,by="category_list",all.x =  T)
final_df <- master_frame_withsector
#------------------------------------------------------------------------------------------------------------------------------------------------------------------                                                              
#CHECKPOINT 5: SECTOR ANALYSIS 2:
final_df <- final_df[!is.na(final_df$raised_amount_usd),]

get_D1_based_on_country <- function(df_main, cntr_code, fund_type){
  D1 <- subset(df_main, country_code == cntr_code & funding_round_type == fund_type & raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)
  return(D1)
}


get_D2_based_on_country <- function(df_main, cntr_code, fund_type){
  
  D1 <- get_D1_based_on_country(df_main, cntr_code, fund_type)
  
  by_sector <- group_by(D1, sector)
  D2 <- summarise(by_sector, no_of_investements = n())
  
  return(D2)
}

get_D3_based_on_country <- function(df_main, cntr_code, fund_type){
  
  D1 <- get_D1_based_on_country(df_main, cntr_code, fund_type)
  
  by_sector <- group_by(D1, sector)
  D3 <- summarise(by_sector, total_investements = sum(raised_amount_usd, na.rm = T))
  D3 <- arrange(D3, desc(total_investements))
  
  return(D3)
}

get.highest.investement.company.by.sector <- function(df_, sector_)
{
  
  #filter out top_sector entries
  df_for_sector <- subset(df_, df_$sector == sector_)
  #group by permalink as it's unique identifier of a company
  df_group_by_company <- group_by(df_for_sector, df_for_sector$permalink)
  #Get total investement of all companies for the top sector(in count of investments)
  total_investement_by_company <- summarise(df_group_by_company, total_investement = sum(raised_amount_usd, na.rm = T))
  #Sort it in dec order of total_invstement
  total_investement_by_company <- arrange(total_investement_by_company, desc(total_investement))
  #Q9 for C1
  #pick the first entry, company that received the max investement
  cmp_paramlink <- as.character(total_investement_by_company[1,1])
  company_received_hightest_investement_for_sector <- companies[companies$permalink == cmp_paramlink, c("name")]
  #company_received_hightest_investement_for_sector <- as.character(total_investement_by_company[1,1])
  
  return(company_received_hightest_investement_for_sector)
  
}

for(country in c(COUNTRY_1, COUNTRY_2, COUNTRY_3) )
{
    cat("Country: ", country, "\n")
    #D1, D2, D3 for each country
    D1 <- get_D1_based_on_country(final_df, country, FT)
    D2 <- get_D2_based_on_country(final_df, country, FT)
    D3 <- get_D3_based_on_country(final_df, country, FT)
    
    #Q1
    no_of_investements <- summarise(D1, no_of_investements = n())
    print(paste("no_of_investements: ", no_of_investements))
    
    #Q2
    amount_of_investements <- summarise(D1, total_investements = sum(raised_amount_usd, na.rm = T) )
    print(paste("amount_of_investements: ", amount_of_investements))
    
    D2 <- arrange(D2, desc(no_of_investements))
    #Q3
    top_Sector <- D2$sector[1]
    print(paste("top_Sector: ", top_Sector))
    
    #Q4
    second_Sector <- D2$sector[2]
    print(paste("second_Sector: ", second_Sector))
    
    #Q5
    third_Sector <- D2$sector[3]
    print(paste("third_Sector: ", third_Sector))
    
    #Q6
    no_of_investements_in_top_Sector <- D2$no_of_investements[1]
    print(paste("no_of_investements_in_top_Sector: ", no_of_investements_in_top_Sector))
    
    #Q7
    no_of_investements_in_second_Sector <- D2$no_of_investements[2]
    print(paste("no_of_investements_in_second_Sector: ", no_of_investements_in_second_Sector))
    
    #Q8
    no_of_investements_in_third_Sector <- D2$no_of_investements[3]
    print(paste("no_of_investements_in_third_Sector: ", no_of_investements_in_third_Sector))
    
    #Q9
    company_received_hightest_investement_for_top_sector = get.highest.investement.company.by.sector(D1, top_Sector)
    print(paste("company_received_hightest_investement_for_top_sector: ", company_received_hightest_investement_for_top_sector))

    #Q10
    company_received_hightest_investement_second_top_sector = get.highest.investement.company.by.sector(D1, second_Sector)
    print(paste("company_received_hightest_investement_second_top_sector: ", company_received_hightest_investement_second_top_sector))
}